<template>
  <div class="top-margin">
    <div class="mb-4">
      <span class="home-title">알림</span>
    </div>
    <div>
      <div class="alarm-container">
        <div class="d-flex justify-content-between align-items-center">
          <div class="alarm-content d-flex align-items-center">
            <div class="d-flex">
              <span
                class="alarm-img mr-3 d-flex justify-content-center align-items-center"
              >
                댓글
              </span>
            </div>
            <div class="alarm-text-content">
              <div class="alarm-title">
                다른 사용자가 내 글에 댓글을 남기셨습니다
              </div>
              <div class="lastTime mt-2">9시간 전</div>
            </div>
          </div>
          <button class="bi bi-chevron-right btn-icon fs-5"></button>
        </div>
      </div>
      <div class="mt-3 mb-3 stroke-default"></div>
    </div>
    <div>
      <div class="alarm-container">
        <div class="d-flex justify-content-between align-items-center">
          <div class="alarm-content d-flex align-items-center">
            <div class="d-flex">
              <span
                class="alarm-img mr-3 d-flex justify-content-center align-items-center"
              >
                댓글
              </span>
            </div>
            <div class="alarm-text-content">
              <div class="alarm-title">
                다른 사용자가 내 글에 댓글을 남기셨습니다
              </div>
              <div class="lastTime mt-2">9시간 전</div>
            </div>
          </div>
          <button class="bi bi-chevron-right btn-icon fs-5"></button>
        </div>
      </div>
      <div class="mt-3 mb-3 stroke-default"></div>
    </div>
    <div>
      <div class="alarm-container">
        <div class="d-flex justify-content-between align-items-center">
          <div class="alarm-content d-flex align-items-center">
            <div class="d-flex">
              <span
                class="alarm-img mr-3 d-flex justify-content-center align-items-center"
              >
                댓글
              </span>
            </div>
            <div class="alarm-text-content">
              <div class="alarm-title">
                다른 사용자가 내 글에 댓글을 남기셨습니다
              </div>
              <div class="lastTime mt-2">9시간 전</div>
            </div>
          </div>
          <button class="bi bi-chevron-right btn-icon fs-5"></button>
        </div>
      </div>
      <div class="mt-3 mb-3 stroke-default"></div>
    </div>
    <div>
      <div class="alarm-container">
        <div class="d-flex justify-content-between align-items-center">
          <div class="alarm-content d-flex align-items-center">
            <div class="d-flex">
              <span
                class="alarm-img mr-3 d-flex justify-content-center align-items-center"
              >
                댓글
              </span>
            </div>
            <div class="alarm-text-content">
              <div class="alarm-title">
                다른 사용자가 내 글에 댓글을 남기셨습니다
              </div>
              <div class="lastTime mt-2">9시간 전</div>
            </div>
          </div>
          <button class="bi bi-chevron-right btn-icon fs-5"></button>
        </div>
      </div>
      <div class="mt-3 mb-3 stroke-default"></div>
    </div>
    <div>
      <div class="alarm-container">
        <div class="d-flex justify-content-between align-items-center">
          <div class="alarm-content d-flex align-items-center">
            <div class="d-flex">
              <span
                class="alarm-img mr-3 d-flex justify-content-center align-items-center"
              >
                댓글
              </span>
            </div>
            <div class="alarm-text-content">
              <div class="alarm-title">
                다른 사용자가 내 글에 댓글을 남기셨습니다
              </div>
              <div class="lastTime mt-2">9시간 전</div>
            </div>
          </div>
          <button class="bi bi-chevron-right btn-icon fs-5"></button>
        </div>
      </div>
      <div class="mt-3 mb-3 stroke-default"></div>
    </div>
    <div>
      <div class="alarm-container">
        <div class="d-flex justify-content-between align-items-center">
          <div class="alarm-content d-flex align-items-center">
            <div class="d-flex">
              <span
                class="alarm-img mr-3 d-flex justify-content-center align-items-center"
              >
                댓글
              </span>
            </div>
            <div class="alarm-text-content">
              <div class="alarm-title">
                다른 사용자가 내 글에 댓글을 남기셨습니다
              </div>
              <div class="lastTime mt-2">9시간 전</div>
            </div>
          </div>
          <button class="bi bi-chevron-right btn-icon fs-5"></button>
        </div>
      </div>
      <div class="mt-3 mb-3 stroke-default"></div>
    </div>
    <div>
      <div class="alarm-container">
        <div class="d-flex justify-content-between align-items-center">
          <div class="alarm-content d-flex align-items-center">
            <div class="d-flex">
              <span
                class="alarm-img mr-3 d-flex justify-content-center align-items-center"
              >
                댓글
              </span>
            </div>
            <div class="alarm-text-content">
              <div class="alarm-title">
                다른 사용자가 내 글에 댓글을 남기셨습니다
              </div>
              <div class="lastTime mt-2">9시간 전</div>
            </div>
          </div>
          <button class="bi bi-chevron-right btn-icon fs-5"></button>
        </div>
      </div>
      <div class="mt-3 mb-3 stroke-default"></div>
    </div>
  </div>
</template>

<script>
export default {};
</script>

<style lang="sass" scoped>
.alarm-img
    width: 60px
    height: 60px
    background-color: lightgrey
    border-radius: 10px

.btn-icon
    -webkit-text-stroke: 2px
</style>
